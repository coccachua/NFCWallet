export default pReject = (err)  => Promise.reject(err)
