// TODO: try dom by ref - requestFullscreen on QR CODE dom element

// <div ref="example" />

// React.findDOMNode(this.refs.example)
