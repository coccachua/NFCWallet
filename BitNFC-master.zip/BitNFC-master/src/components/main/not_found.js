import React from 'React'
import Comp from '../comp'

// TODO - NotFound component
export default class NotFound extends Comp {
  render() {
    <div>Not found</div>
  }
}


