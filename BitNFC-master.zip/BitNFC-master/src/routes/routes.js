import React from 'react'
import { Router, Route, IndexRoute, Link, hashHistory } from 'ReactRouter'

// export default(
//   <Route path="/" component={Main}>
//     <Route path="/lolno" component={Antani} />
//   </Route>
// )
